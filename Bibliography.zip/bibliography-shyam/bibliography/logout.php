// Just calls logout function
<?php
include 'dbc.php';
logout();
?> 